package com.upgrad.hirewheels.practice;

public class UserBalanceImpl implements UserBalanceInterface {

    public double getBalance() {
        return 1000.00;
    }
}
